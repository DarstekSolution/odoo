:orphan:

These files should be run via pytest_, simply install pytest and from the top
of the Odoo project run ``pytest doc/_extensions``.

.. _pytest: https://pytest.org/
