Spain, 2016-11-21

Diagram Software, S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jose Zambudio jose.zambudio@diagram.es https://github.com/zamberjo

List of contributors:

Cristian Moncho cristian.moncho@diagram.es https://github.com/crimoniv
Jose Zambudio jose.zambudio@diagram.es https://github.com/zamberjo
Almudena de la Puente almudena.delapuente@diagram.es https://github.com/almumu
Mauro Cebriá mauro.cebria@diagram.es https://github.com/maurochip
Pedro Albujer pedro.albujer.rico@diagram.es https://github.com/P4R
Rubén Cerdà ruben.cerda.roig@diagram.es https://github.com/rubencr7
