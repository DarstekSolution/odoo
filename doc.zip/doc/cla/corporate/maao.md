Kyiv, Ukraine, 2017-05-29

Management and Accouting online llc agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Management and Accouting online llc info@maao.com.ua https://github.com/management-and-acounting-on-line

List of contributors:

Ostap Yakovenko ostap.yakovenko@maao.com.ua https://github.com/OstapYakovenko
Dmytro Katyukha dmytro.katyukha@maao.com.ua https://github.com/katyukha
