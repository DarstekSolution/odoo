India, U.A.E, Singapore, 2015-02-10

Tech Receptives, Tech-Receptives Solutions Pvt. Ltd, Tech Receptives IT Solutions FZC and Tech Receptives Asia Pacific Pte Ltd agrees to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Parthiv Patel parthiv@techreceptives.com https://github.com/techreceptives

List of contributors:

Parthiv Patel parthiv@techreceptives.com https://github.com/parthivgls

