KMEE, Brazil, 2015-12-04

KMEE INFORMATICA LTDA agrees to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Luis Felipe Miléo mileo@kmee.com.br https://github.com/kmee

List of contributors:

Luis Felipe Miléo mileo@kmee.com.br https://github.com/mileo
Ananias Pereira Batista Filho ananias@kmee.com.br  https://github.com/ananiasfilho
Michell Stuttigart michell.stuttigart@kmee.com.br https://github.com/mstuttgart
Fernando Marcato Rodrigues fernando.marcato@kmee.com.br https://github.com/fernandomr
Daniel Sadamo   daniel.sadamo@kmee.com.br https://github.com/sadamo
Bianca Tella bianca.tella@kmee.com.br https://github.com/biancatella
Luiz Felipe do Divino luiz.divino@kmee.com.br https://github.com/lfdivino