Netherlands, 18-1-2018

Odoo Experts agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Erwin van der Ploeg erwin@bas-solutions.nl https://github.com/erwin-bas-solutions

List of contributors:

Erwin van der Ploeg erwin@odooexperts.nl https://github.com/ploegvde
Yenthe Van Ginneken yenthe@odooexperts.nl https://github.com/Yenthe666
