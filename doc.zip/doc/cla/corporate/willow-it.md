Australia, 2015-07-20

Willow IT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Richard deMeester richard@willowit.com.au https://github.com/richard-willowit

List of contributors:

Richard deMeester richard@willowit.com.au https://github.com/richard-willowit
Douglas Parker doug@willowit.com.au https://github.com/doug-willowit
Bhavya Malik bhavya@willowit.com.au https://github.com/bhavya-willowit
Jon Wilson jon@willowit.com.au https://github.com/jon-willowit
