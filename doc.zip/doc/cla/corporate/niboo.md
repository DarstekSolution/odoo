Belgium, 2017-09-25

Niboo agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Samuel Lefever sam@niboo.be https://github.com/samuellefever

List of contributors:

Samuel Lefever sam@niboo.be https://github.com/samuellefever
Pierre Faniel pierre@niboo.be https://github.com/PierreFaniel
Jerome Guerriat jerome@niboo.be https://github.com/jguerriat
Jeremy Van Driessche jeremy@niboo.be https://github.com/jvandri
Gael Rabier gael@niboo.be https://github.com/gaelrabier
Tobias Zehntner tobias@niboo.be https://github.com/twobeers83
Alexandre Dutry alexandre@nboo.be https://github.com/AlexandreDz
