Germany, 9-30-2015

Big Consulting GmbH agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Thorsten Vocks thorsten.vocks@openbig.org https://github.com/tv-openbig

List of contributors:

Thorsten Vocks thorsten.vocks@openbig.org https://github.com/tv-openbig
Heike Vocks heike.vocks@openbig.org https://github.com/hv-openbig
Jan Dasenbrock jan.dasenbrock@openbig.org https://github.com/jd-openbig
