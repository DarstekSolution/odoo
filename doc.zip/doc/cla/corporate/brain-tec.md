Switzerland, 2015-11-09

brain-tec AG agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Pascal Zenklusen pascal.zenklusen@braintec-group.com https://github.com/BT-pzenklusen

List of contributors:

Álvaro Estébanez López alvaro.estebanez@braintec-group.com https://github.com/BT-aestebanez
Andreas Stauder andreas.stauder@braintec-group.com https://github.com/BT-astauder
Carlos Millán de Silva carlos.millan@braintec-group.com https://github.com/BT-cmillan
Cesar Andres Sanchez cesar-andres.sanchez@braintec-group.com https://github.com/BT-csanchez
Carlos Serra Toro carlos.serra@braintec-group.com https://github.com/BT-cserra
Dominik Schleich dominik.schleich@braintec-group.com https://github.com/BT-dschleich
Frédéric Aebi frederic.aebi@braintec-group.com https://github.com/BT-faebi
Fréderic Garbely frederic.garbely@braintec-group.com https://github.com/BT-fgarbely
Florian Wonneberger florian.wonneberger@braintec-group.com https://github.com/BT-fwonneberger
Jorge Asensio jorge.asensio@braintec-group.com https://github.com/BT-jasensio
Jose J. Duran-Martin jose-javier.duran@braintec-group.com https://github.com/BT-jduran
Federico Javier Mesa Hidalgo javier.mesa@braintec-group.com https://github.com/BT-jmesa
Joël Michaud joel.michaud@braintec-group.com https://github.com/BT-jmichaud
Jose Montero jose.montero@braintec-group.com https://github.com/BT-jmontero
José Luis Vallejo Diaz jose.vallejo@braintec-group.com https://github.com/BT-jvallejo
Kumar Aberer kumar.aberer@braintec-group.com https://github.com/BT-kaberer
Matt Fasola matt.fasola@braintec-group.com https://github.com/BT-mfasola
Miguel Tallon Benitez miguel.tallon@braintec-group.com https://github.com/BT-mtallon
Nicolas Frei nicolas.frei@braintec-group.com https://github.com/BT-nfrei
Nathanael Leutenegger nathanael.leutenegger@braintec-group.com https://github.com/BT-nleutenegger
Olivier Jossen olivier.jossen@braintec-group.com https://github.com/BT-ojossen
Philipp Fux philipp.fux@braintec-group.com https://github.com/BT-pfux
Raúl Martín raul.martin@braintec-group.com https://github.com/BT-rmartin
Silvan Wyden silvan.wyden@braintec-group.com https://github.com/BT-swyden
Timka Piric Muratovic timka.piric@braintec-group.com https://github.com/BT-tpiric
Pascal Zenklusen pascal.zenklusen@braintec-group.com https://github.com/BT-pzenklusen
Nadal Francisco Garcia nadal.francisco@braintec-group.com https://github.com/BT-nfrancisco