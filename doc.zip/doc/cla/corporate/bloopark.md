Germany 2015-02-25

bloopark systems GmbH & Co. KG agrees to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jens Holze  jholze@bloopark.de https://github.com/jholze

List of contributors:

Jens Holze jholze@bloopark.de https://github.com/jholze
Christoph Giesel cgiesel@bloopark.de https://github.com/christophlsa
Benjamin Bachmann bBachmann@bloopark.de https://github.com/benniphx
Robert Rübner rruebner@bloopark.de https://github.com/rruebner
Florian Fischer ffischer@bloopark.de https://github.com/florianfischer
Mercerdes Scenna mscenna@bloopark.de https://github.com/mscenna
Andrei Poehlmann andrei.poehlmann90@gmail.com https://github.com/reinka
