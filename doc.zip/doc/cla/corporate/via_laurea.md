Lithuania, 2015-06-29

Via laurea agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Saulius Zilys saulius@vialaurea.lt (up to 2017-04-24)

List of contributors:

Saulius Zilys saulius@vialaurea.lt (up to 2017-04-24)
