Spain, 2017-05-28

LANDOO S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Josean Soroa js@landoo.es https://github.com/js-landoo

List of contributors:

Josean Soroa js@landoo.es https://github.com/js-landoo
Ignacio Garbizu ig@landoo.es https://github.com/ig-landoo
