Belgium, 2018-05-18

Accomodata agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jos De Graeve Jos.DeGraeve@accomodata.be https://github.com/JosDeGraeve

List of contributors:

* James De Ridder james.de.ridder@accomodata.be https://github.com/Krynox
* Manuel Dellisse manuel.dellisse@accomodata.be https://github.com/Manuel-Dellisse
* Brecht Verhaeghe brecht.verhaeghe@accomodata.be https://github.com/brechtverhaeghe
* Ronny Houben ronny.houben@accomodata.be https://github.com/ronnyhouben
* Jean-Paul Robineau jean-paul.robineau@accomodata.be https://github.com/jeanpaulrobineau
* Jos De Graeve jos.degraeve@accomodata.be https://github.com/JosDeGraeve
