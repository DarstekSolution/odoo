The Netherlands, 2018-10-24

Brahoo B.V. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Cas Vissers c.vissers@brahoo.nl https://github.com/CasVissers

List of contributors:

Cas Vissers c.vissers@brahoo.nl https://github.com/CasVissers