Belgium, 2015-04-23

TAKTIK SA/NV agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Maxime Vanderhaeghe mv@taktik.be https://github.com/mv-taktik

List of contributors:

Adil Houmadi ah@taktik.be https://github.com/ah-taktik
David Lefever dl@taktik.be https://github.com/lefeverd
François Vanderborght fv@taktik.be https://github.com/fv-taktik
Kevin Goris kg@taktik.be https://github.com/kg-taktik
Matthias Vercruysse mve@taktik.be https://github.com/mve-taktik
Maxime Vanderhaeghe mv@taktik.be https://github.com/mv-taktik
