Belgium, 2015-06-04

DynApps N.V. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Pieter Paulussen pieter.paulussen@dynapps.be https://github.com/PieterPaulussen

List of contributors:

Pieter Paulussen pieter.paulussen@dynapps.be https://github.com/PieterPaulussen
Raf Ven raf.ven@dynapps.be https://github.com/rven
Kurt Schmitz kurt.schmitz@dynapps.be https://github.com/kurt-schmitz
Rod Schouteden rod.schouteden@dynapps.be https://github.com/schout-it
