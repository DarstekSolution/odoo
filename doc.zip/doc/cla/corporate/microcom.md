Canada, 2016-06-09

Microcom agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Martin Malorni mmalorni@gmail.com https://github.com/mmalorni

List of contributors:

- Vincent Coll vincentgagnnoncoll@gmail.com https://github.com/vincentcoll
- Stéphane Le Cornec stephane.lecornec@gmail.com https://github.com/coleste
- Eric Lemire elemire@users.noreply.github.com https://github.com/elemire
- Martin Malorni mmalorni@gmail.com https://github.com/mmalorni
- Samuel Chamberland sc.microcom@gmail.com https://github.com/sc-microcom
- Noreddine Ben Jillali nbj.microcom@gmail.com https://github.com/nbj-microcom
- Rim Ben Dhaou rbd.microcom@gmail.com https://github.com/rbd-microcom
