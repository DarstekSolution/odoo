FRANCE, 2016-01-06

Sudokeys agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

David GUESSAB david@sudokeys.com https://github.com/chouab

List of contributors:

David GUESSAB david@sudokeys.com https://github.com/chouab
Nicolas JEUDY nicolas@sudokeys.com https://github.com/njeudy
