Spain, 2015-04-22

Avanzosc, S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Ana Juaristi anajuaristi@avanzosc.es https://github.com/anajuaristi

List of contributors:

Ana Juaristi anajuaristi@avanzosc.es https://github.com/anajuaristi
Ainara Galdona ainaragaldona@avanzosc.es https://github.com/agaldona
Alfredo de la Fuente alfredodelafuente@avanzosc.es https://github.com/alfredoavanzosc
Daniel Campos danielcampos@avanzosc.es https://github.com/Daniel-CA
Ibone Juaristi ibonejuaristi@avanzosc.es https://github.com/ibonejuaristi
Mikel Arregi mikelarregi@avanzosc.es https://github.com/mikelarre
Oihane Crucelaegui oihanecrucelaegi@avanzosc.es https://github.com/oihane
