United States, 2015-09-18

Sodexis, Inc. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Stephan Keller skeller@sodexis.com https://github.com/stephankeller

List of contributors:

Stephan Keller skeller@sodexis.com https://github.com/stephankeller
Suganthi Karunanithi ksuganthi@sodexis.com https://github.com/suganthikarunanithi
Xavier Dass xavier@sodexis.com https://github.com/xavier-dass
Atchuthan atchuthan@sodexis.com https://github.com/atchuthan
Dhinesh dhinesh@sodexis.com https://github.com/dvdhinesh
SodexisTeam dev@sodexis.com https://github.com/SodexisTeam
