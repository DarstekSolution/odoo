India, 2015-02-10

Serpent Consulting Services Pvt Ltd. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Serpent Consulting Services Pvt Ltd. contact@serpentcs.com https://github.com/JayVora-SerpentCS

List of contributors:

Jay Vora jay.vora@serpentcs.com https://github.com/JayVora-SerpentCS
Husen Daudi husen.daudi@serpentcs.com https://github.com/hda
