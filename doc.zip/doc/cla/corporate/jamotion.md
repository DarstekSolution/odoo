Switzerland, 19.02.2015

Jamotion GmbH agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Renzo Meister, rm@jamotion.ch https://github.com/jamotion

List of contributors:

Renzo Meister, rm@jamotion.ch https://github.com/rm-jamotion
Patrick Reiser, pr@jamotion.ch https://github.com/prjamo
Gregor Lazzarato, gl@jamotion.ch https://github.com/gregorlazzarato
