Germany, 2016-04-20

initOS GmbH agrees to the terms of the Odoo Corporate
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Frederik Kramer frederik.kramer@initos.com https://github.com/OSevangelist

List of contributors:

Markus Schneider markus.schneider@initos.com https://github.com/OSguard
Thomas Rehn thomas.rehn@initos.com https://github.com/tremlin
Katja Matthes katja.matthes@initos.com https://github.com/kmatthes
Frederik Kramer frederik.kramer@initos.com https://github.com/OSevangelist
Nikolina Todorova nikolina.todorova@initos.com https://github.com/ntodorova
Peter Hahn peter.hahn@initos.com https://github.com/codingforfun
Claudia Haida claudia.haida@initos.com
Andreas Zöllner andreas.zoellner@initos.com https://github.com/azoellner
Rami Alwafaie rami.alwafaie@initos.com https://github.com/rami-wafaie
Florian Kantelberg florian.kantelberg@initos.com https://github.com/fkantelberg
