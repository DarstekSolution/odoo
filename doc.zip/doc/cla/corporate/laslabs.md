United States, 2015-08-23

LasLabs, Inc. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

David Lasley dave@laslabs.com https://github.com/laslabs

List of contributors:

David Lasley dave@laslabs.com https://github.com/lasley
Ted Salmon tsalmon@laslabs.com https://github.com/t3ddftw