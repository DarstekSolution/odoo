Georgia, 2015-06-30

Delta Comm LLC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Karlo Matitaishvili kmatitaishvili@delta-comm.ge https://github.com/kmatitaishvili

List of contributors:

Temur Vibliani tvibliani@delta-comm.ge https://github.com/tvibliani
Mikheil Tutberidze mtutberidze@delta-comm.ge https://github.com/mtutberidze
