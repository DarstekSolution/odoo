Brazil, 2015-06-25

Uhlig & Korovsky Tecnologia Ltda - ME agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Carlos Alberto Cipriano Korovsky contato@uktech.com.br https://github.com/uktechbr

List of contributors:

Carlos Alberto Cipriano Korovsky carlos.korovsky@uktech.com.br https://github.com/carlos-korovsky