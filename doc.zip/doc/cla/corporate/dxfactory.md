Bulgaria, 2017-10-27

dXFactory ood agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Selvaraj Ramkumar rs@dxfactory.eu

List of contributors:

Jean-Luc Dumont
Selvaraj Ramkumar
Dimitar Epitropov
Nataliya Minkovska
