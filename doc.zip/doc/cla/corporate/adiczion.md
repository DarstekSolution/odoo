France, 2016-04-11

Adiczion agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Christophe 2cadz@adiczion.net https://github.com/2cadz

List of contributors:

Christophe 2cadz@adiczion.net https://github.com/2cadz
