Cuba, 2017-07-03

Merchise Autrement [~º/~] agrees to the terms of the Odoo Corporate
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Manuel Vázquez Acosta manuel@merchise.org https://github.com/mvaled

List of contributors:

Manuel Vázquez Acosta manuel@merchise.org https://github.com/mvaled
Johanny Rivera johanny@merchise.org
Henrik Pestano henrik@merchise.org https://github.com/hpestano
Oraldo Jacinto Simón oraldo@merchise.org
Sergio Valdés sergiov@merchise.org
Medardo Rodríguez med@merchise.org https://github.com/med-merchise
Abel Firvida firvida@merchise.org
Abel Firvida abel@merchise.org
Mónica Díaz Pena monicadp@merchise.org  https://github.com/mdpena
