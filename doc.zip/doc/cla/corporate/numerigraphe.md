France, 2015-04-22

Numérigraphe agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Lionel Sausin ls@numerigraphe.com https://github.com/clonedagain

List of contributors:

Lionel Sausin ls@numerigraphe.com https://github.com/clonedagain
Loïc Bellier lb@numerigraphe.com https://github.com/lbellier
