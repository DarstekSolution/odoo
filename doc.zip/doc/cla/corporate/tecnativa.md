Spain, 2017-04-04

Tecnativa S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Pedro M. Baeza pedro.baeza@tecnativa.com https://github.com/pedrobaeza

List of contributors:

Pedro M. Baeza pedro.baeza@tecnativa.com https://github.com/pedrobaeza
Rafael Blasco rafael.blasco@tecnativa.com https://github.com/rafaelbn
Sergio Teruel sergio.teruel@tecnativa.com https://github.com/sergio-teruel
Carlos Dauden carlos.dauden@tecnativa.com https://github.com/carlosdauden
Jairo Llopis jairo.llopis@tecnativa.com https://github.com/yajo
Vicent Cubells vicent.cubells@tecnativa.com https://github.com/cubells
Luis Montalba luis.montalba@tecnativa.com https://github.com/luismontalba
David Vidal david.vidal@tecnativa.com https://github.com/chienandalu
