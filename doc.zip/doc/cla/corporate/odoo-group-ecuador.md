Ecuador, February 1, 2017

Odoo-Group-Ecuador agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Odoo-Group-Ecuador odoo.group.ecuador@gmail.com https://www.github.com/odoo-group-ecuador

List of contributors:

Juan Manuel Rosero Puente snowblow07@gmail.com https://www.github.com/snowblow
