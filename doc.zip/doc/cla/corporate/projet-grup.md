Turkey, 2017-12-05

Projet Yazilim Ve Danismanlik AS agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Can Tecim can.tecim@gmail.com https://github.com/cantecim

List of contributors:

Can Tecim can.tecim@gmail.com https://github.com/cantecim  
Can Tecim dev@projetgrup.com https://github.com/devprojetgrup  
Selahattin Ünlü selahattin.unlu@yandex.com https://github.com/selahattinunlu  
Abdurrahman Işık isikabdurrahman@yahoo.com https://github.com/abdurrahman  
