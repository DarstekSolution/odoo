Netherlands, 2015-03-09

Updated:
    2016-05-27
    2017-06-27

Therp BV agrees to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

We declare that we are authorized and able to make this agreement and sign
this declaration.

Signed,

*  Ronald Portier ronald@therp.nl https://github.com/nl66278

List of contributors:

*  Giovanni Capalbo giovanni@therp.nl https://github.com/gfcapalbo
*  Holger Brunn hbrunn@therp.nl https://github.com/hbrunn
*  Lara Freeke lfreeke@therp.nl https://github.com/lfreeke
*  Ronald Portier ronald@therp.nl https://github.com/nl66278
*  George Daramouskas gdaramouskas@therp.nl https://github.com/daramousk

