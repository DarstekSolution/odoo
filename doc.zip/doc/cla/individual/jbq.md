France, 2015-06-01

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jean-Baptiste Quenot jbq@caraldi.com https://github.com/jbq
