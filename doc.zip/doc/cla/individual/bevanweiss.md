Australia, 17 May 2015

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Bevan Weiss bevan.weiss@gmail.com https://github.com/bevanweiss
