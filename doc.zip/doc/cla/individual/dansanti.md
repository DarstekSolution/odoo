Chile, 2016-05-31

I hereby agree to the terms of the Odoo Individual Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Daniel Santibáñez Polanco dansanti@gmail.com  https://github.com/dansanti