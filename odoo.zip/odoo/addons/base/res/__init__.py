# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import report_paperformat
from . import res_country
from . import res_lang
from . import res_partner
from . import res_bank
from . import res_config
from . import res_currency
from . import res_company
from . import res_users
from . import res_request
from . import ir_property
