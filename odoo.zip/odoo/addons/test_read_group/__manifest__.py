# -*- coding: utf-8 -*-
{
    'name': "test read_group",
    'description': "Tests for read_group",

    'category': 'Tests',
    'version': '0.1',

    'depends': ['base'],
    'data': ['ir.model.access.csv'],
}
