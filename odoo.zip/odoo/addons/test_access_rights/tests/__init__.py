from . import test_ir_rules
