{
    'name': 'test of access rights and rules',
    'description': "Testing of access restrictions",
    'version': '0.0.1',
    'data': ['ir.model.access.csv'],
}
