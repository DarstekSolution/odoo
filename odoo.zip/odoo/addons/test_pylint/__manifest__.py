# -*- coding: utf-8 -*-
{
    'name': 'test-eval',
    'version': '0.1',
    'category': 'Tests',
    'description': """A module to test Odoo with pylint.""",
    'maintainer': 'Odoo SA',
    'depends': ['base'],
    'installable': True,
    'auto_install': False,
}
